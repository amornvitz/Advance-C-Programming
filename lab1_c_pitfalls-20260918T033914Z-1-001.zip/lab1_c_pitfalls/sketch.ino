/*==============================================================================
 * LAB 1 -- BUG HUNT:  8 defects that compile cleanly and behave wrongly
 *
 * TIME     : 35 minutes
 * GOAL     : Find all 8 defects, explain WHY each one is wrong on an 8-bit
 *            target, and fix them.  Do NOT rewrite the program -- make the
 *            smallest correct change for each defect.
 *
 * RULES    : 1. Read first, run second.  Predict the output before you upload.
 *            2. Every defect below is a real one taken from production
 *               appliance firmware.  None of them is a typo.
 *            3. Turn on all warnings.  In Wokwi the build is already
 *               -Wall; in your own IDE use -Wall -Wextra -Wconversion.
 *
 * HINT     : on ATmega328P   sizeof(int) == 2   and   sizeof(long) == 4
 *==============================================================================*/

#include <Arduino.h>
#include <stdint.h>

/* ---- shared with the ISR --------------------------------------------- */
uint8_t  g_tick_flag = 0;          /* DEFECT 5 lives here                  */
uint16_t g_events    = 0;

/* ---- a sensor record ------------------------------------------------- */
struct sensor_record {
    uint8_t  id;
    uint16_t raw;
    uint8_t  status;
};

/* ---- DEFECT 6: array length inside a function ------------------------ */
static uint16_t sum_samples(uint8_t samples[])
{
    uint16_t total = 0;
    for (uint8_t i = 0; i < sizeof(samples); i++) {
        total += samples[i];
    }
    return total;
}

/* ---- DEFECT 1: accumulator too small --------------------------------- */
static uint8_t average_of_ten(const uint8_t *v)
{
    uint8_t sum = 0;
    for (uint8_t i = 0; i < 10; i++) {
        sum += v[i];
    }
    return sum / 10;
}

/* ---- DEFECT 2: countdown that never ends ----------------------------- */
static uint8_t count_down_from_ten(void)
{
    uint8_t iterations = 0;
    for (uint8_t i = 10; i >= 0; i--) {
        iterations++;
        if (iterations > 200) {        /* escape hatch so the lab still runs */
            break;
        }
    }
    return iterations;
}

/* ---- DEFECT 7: shift wider than the type ----------------------------- */
static uint32_t bit_mask_for(uint8_t position)
{
    return (1 << position);
}

void setup(void)
{
    Serial.begin(115200);
    while (!Serial) { }
    Serial.println(F("=== LAB 1: BUG HUNT ==="));

    /* ---------------- DEFECT 1 ---------------- */
    uint8_t readings[10] = { 30, 30, 30, 30, 30, 30, 30, 30, 30, 30 };
    Serial.print(F("1. average of ten 30s        = "));
    Serial.print(average_of_ten(readings));
    Serial.println(F("   (expected 30)"));

    /* ---------------- DEFECT 2 ---------------- */
    Serial.print(F("2. loop iterations 10 -> 0   = "));
    Serial.print(count_down_from_ten());
    Serial.println(F("   (expected 11)"));

    /* ---------------- DEFECT 3: int is 16 bits here ---------------- */
    int timeout_ms = 60 * 1000;
    Serial.print(F("3. 60 seconds in ms          = "));
    Serial.print(timeout_ms);
    Serial.println(F("   (expected 60000)"));

    /* ---------------- DEFECT 4: plain char signedness ---------------- */
    char error_code = 200;
    Serial.print(F("4. error code 200 > 127 ?    = "));
    Serial.print((error_code > 127) ? F("yes") : F("no"));
    Serial.println(F("   (expected yes)"));

    /* ---------------- DEFECT 6 ---------------- */
    uint8_t block[8] = { 1, 2, 3, 4, 5, 6, 7, 8 };
    Serial.print(F("6. sum of 1..8               = "));
    Serial.print(sum_samples(block));
    Serial.println(F("   (expected 36)"));

    /* ---------------- DEFECT 7 ---------------- */
    Serial.print(F("7. bit mask for position 20  = 0x"));
    Serial.print(bit_mask_for(20), HEX);
    Serial.println(F("   (expected 0x100000)"));

    /* ---------------- DEFECT 8: struct size assumption ---------------- */
    Serial.print(F("8. sizeof(sensor_record)     = "));
    Serial.print(sizeof(struct sensor_record));
    Serial.println(F("   bytes -- is 1+2+1 = 4 guaranteed?"));

    Serial.println(F("\nNow find DEFECT 5 -- it is in loop(), not here."));
}

void loop(void)
{
    /* ---------------- DEFECT 5 ----------------
     * g_tick_flag is set by an interrupt service routine elsewhere in the
     * system.  Build this at -O2 and watch what the optimiser does to the
     * while loop below.  Why?  What one keyword fixes it?
     *
     * (In this lab the ISR is simulated by the timer0 overflow that Arduino
     *  already installs, so the flag is set from millis().)               */
    static uint32_t last = 0;
    if (millis() - last >= 1000UL) {
        last = millis();
        g_tick_flag = 1;
    }

    while (g_tick_flag == 0) {
        /* waiting for the tick */
    }
    g_tick_flag = 0;
    g_events++;

    Serial.print(F("tick "));
    Serial.println(g_events);
}
